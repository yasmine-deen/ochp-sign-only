import crypto from 'crypto';

const SECRET = process.env.SIGNING_SECRET;
if(!SECRET){
  console.warn('SIGNING_SECRET is not set. Set it in Vercel → Project → Settings → Environment Variables.');
}

export function makeToken(data: unknown, ttlDays = 7){
  const payload = { data, exp: Date.now() + (ttlDays * 864e5) };
  const b64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SECRET || 'dev').update(b64).digest('base64url');
  return `${b64}.${sig}`;
}

export function verifyToken(token: string){
  const [b64, sig] = token.split('.');
  const expect = crypto.createHmac('sha256', SECRET || 'dev').update(b64).digest('base64url');
  if(sig !== expect) throw new Error('Invalid token');
  const { data, exp } = JSON.parse(Buffer.from(b64, 'base64url').toString());
  if(exp && Date.now() > exp) throw new Error('Expired');
  return data as Record<string, unknown>;
}
