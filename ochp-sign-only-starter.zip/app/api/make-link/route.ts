import { NextRequest } from "next/server";
import { makeToken, verifyToken } from "@/lib/signing";

export async function POST(req: NextRequest){
  try{
    const { data, ttlDays } = await req.json();
    const token = makeToken(data, ttlDays ?? 7);
    const url = `${new URL(req.url).origin}/sign/${encodeURIComponent(token)}`;
    return Response.json({ url });
  }catch(e:any){
    return Response.json({ error: e?.message || 'Bad request' }, { status: 400 });
  }
}

// GET used to preview data from a token (read-only)
export async function GET(req: NextRequest){
  try{
    const token = req.nextUrl.searchParams.get('token');
    if(!token) return Response.json({ error: 'Missing token' }, { status: 400 });
    const data = verifyToken(token);
    return Response.json({ data });
  }catch(e:any){
    return Response.json({ error: e?.message || 'Invalid token' }, { status: 400 });
  }
}
