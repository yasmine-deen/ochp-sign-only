import { NextRequest } from "next/server";
import { verifyToken } from "@/lib/signing";
import { PDFDocument, rgb } from "pdf-lib";
import { put } from "@vercel/blob";

export async function POST(req: NextRequest){
  try{
    const formData = await req.formData();
    const token = String(formData.get("token") || '');
    const sigDataURL = String(formData.get("sig") || '');
    if(!token || !sigDataURL) return Response.json({ error: 'Missing fields' }, { status: 400 });

    // 1) Verify token (reject tampering or expiration)
    const data = verifyToken(token);

    // 2) Load PDF template
    // NOTE: Replace 'ochp-form.pdf' with your template if needed.
    const templateUrl = new URL("../../../../public/templates/ochp-form.pdf", import.meta.url);
    const templateBytes = await fetch(templateUrl).then(r => r.arrayBuffer());
    const pdfDoc = await PDFDocument.load(templateBytes);

    // 3) Embed signature at a reserved location (adjust coordinates to your form)
    const pngBytes = Buffer.from(sigDataURL.split(',')[1], 'base64');
    const pngImage = await pdfDoc.embedPng(pngBytes);
    const page = pdfDoc.getPages()[pdfDoc.getPageCount() - 1];
    page.drawImage(pngImage, { x: 72, y: 110, width: 220, height: 70 });

    // Optional: add audit line
    const now = new Date().toISOString();
    page.drawText(`Signed ${now}`, { x: 72, y: 90, size: 9, color: rgb(0,0,0) });

    // 4) Save to Vercel Blob (public URL)
    const pdfBytes = await pdfDoc.save();
    const filename = `signed/${Date.now()}-signed.pdf`;
    const { url } = await put(filename, new Blob([pdfBytes], { type:'application/pdf' }), { access: 'public' });

    return Response.json({ ok:true, url });
  }catch(e:any){
    return Response.json({ error: e?.message || 'Submit failed' }, { status: 400 });
  }
}
