export default function SuccessPage({ searchParams }: { searchParams: { url?: string } }){
  const url = searchParams?.url;
  return (
    <div style={{maxWidth:720, margin:'40px auto', padding:20, fontFamily:'system-ui, Arial'}}>
      <h1 style={{fontSize:22, fontWeight:700}}>Thank you — signed successfully</h1>
      <p style={{marginTop:8}}>Your signed document has been saved.</p>
      {url && <p>Download: <a href={url} target="_blank" rel="noreferrer" style={{color:'#0b66ff', wordBreak:'break-all'}}>{url}</a></p>}
    </div>
  );
}
