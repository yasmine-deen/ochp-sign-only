'use client';
import { useRef, useState, useEffect } from 'react';
import SignatureCanvas from 'react-signature-canvas';

export default function SignPage({ params }: { params: { token: string } }) {
  const sigRef = useRef<SignatureCanvas | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);
  const token = decodeURIComponent(params.token);

  useEffect(()=>{
    // Fetch read-only data from token (server verifies in API)
    (async()=>{
      const res = await fetch(`/api/make-link?token=${encodeURIComponent(token)}`);
      const out = await res.json();
      if(!res.ok) setError(out?.error || 'Invalid link');
      else setData(out?.data);
    })();
  },[token]);

  async function handleSubmit(e: React.FormEvent){
    e.preventDefault();
    setError(null);
    if(!sigRef.current || sigRef.current.isEmpty()) {
      setError('Please draw your signature.');
      return;
    }
    setSubmitting(true);
    try{
      const sigDataURL = sigRef.current.getTrimmedCanvas().toDataURL('image/png');
      const form = new FormData();
      form.append('token', token);
      form.append('sig', sigDataURL);
      const res = await fetch('/api/submit-signature', { method:'POST', body: form });
      const out = await res.json();
      if(!res.ok || !out?.ok){
        throw new Error(out?.error || 'Submit failed');
      }
      // Show the link
      window.location.href = `/sign/success?url=${encodeURIComponent(out.url)}`;
    }catch(e:any){
      setError(e.message || 'Error');
    }finally{
      setSubmitting(false);
    }
  }

  return (
    <div style={{maxWidth:840, margin:'40px auto', padding:20, fontFamily:'system-ui, Arial'}}>
      <h1 style={{fontSize:22, fontWeight:700}}>Confirm & Sign</h1>
      {!data && !error && <p>Loading…</p>}
      {error && <p style={{color:'crimson'}}>{error}</p>}
      {data && (
        <div>
          <div style={{marginTop:12, fontSize:14, lineHeight:1.5}}>
            {/* Render read-only fields */}
            {Object.entries(data).map(([k,v])=> (
              <div key={k}><b>{k}</b>: {typeof v === 'object' ? JSON.stringify(v) : String(v)}</div>
            ))}
          </div>

          <form onSubmit={handleSubmit} style={{marginTop:20}}>
            <div style={{border:'1px solid #ddd', borderRadius:8, padding:12}}>
              <SignatureCanvas ref={sigRef} penColor="black" canvasProps={{width:760, height:180, style:{width:'100%', height:180}}}/>
            </div>
            <p style={{fontSize:12, opacity:.7, marginTop:8}}>By signing, you confirm the information above is accurate.</p>
            <button disabled={submitting} style={{marginTop:12, padding:'10px 16px', background:'#111', color:'#fff', borderRadius:8}}>
              {submitting? 'Submitting…' : 'Submit Signature'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
