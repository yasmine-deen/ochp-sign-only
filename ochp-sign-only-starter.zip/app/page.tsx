export default function Home(){
  return (
    <div style={{maxWidth:720, margin:'40px auto', padding:20, fontFamily:'system-ui, Arial'}}>
      <h1 style={{fontSize:22, fontWeight:700}}>OCHP Sign-Only Starter</h1>
      <p style={{marginTop:8}}>
        Use <a href="/admin" style={{color:'#0b66ff'}}>Admin</a> to create a sign link, then send it to a candidate.
      </p>
    </div>
  );
}
