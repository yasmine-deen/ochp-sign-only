'use client';
import { useState } from 'react';

export default function AdminPage(){
  const [jsonText, setJsonText] = useState('{}');
  const [link, setLink] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function createLink(){
    setLoading(true); setErr(null); setLink(null);
    try{
      const parsed = JSON.parse(jsonText);
      const res = await fetch('/api/make-link',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data:parsed})});
      const out = await res.json();
      if(!res.ok || !out?.url) throw new Error(out?.error || 'Failed to create link');
      setLink(out.url);
    }catch(e:any){
      setErr(e.message || 'Error');
    }finally{
      setLoading(false);
    }
  }

  return (
    <div style={{maxWidth:840, margin:'40px auto', padding:20, fontFamily:'system-ui, Arial'}}>
      <h1 style={{fontSize:22, fontWeight:700}}>Admin • Create Sign Link</h1>
      <p style={{opacity:.8, marginTop:6}}>Paste the candidate's frozen answers (JSON). Click <b>Create Link</b> and send the link to the candidate.</p>
      <textarea value={jsonText} onChange={e=>setJsonText(e.target.value)} rows={16} style={{width:'100%', fontFamily:'ui-monospace, Menlo, monospace', fontSize:14, marginTop:12}} />
      <div style={{marginTop:12, display:'flex', gap:12}}>
        <button onClick={createLink} disabled={loading} style={{padding:'10px 16px', background:'#111', color:'#fff', borderRadius:8}}>{loading?'Creating...':'Create Link'}</button>
        {err && <span style={{color:'crimson'}}>{err}</span>}
      </div>
      {link && <div style={{marginTop:16}}>
        <div>Sign URL:</div>
        <a href={link} target="_blank" rel="noreferrer" style={{wordBreak:'break-all', color:'#0b66ff'}}>{link}</a>
      </div>}
    </div>
  );
}
